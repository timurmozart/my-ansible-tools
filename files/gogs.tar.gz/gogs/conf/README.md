Execute following command in ROOT directory when anything is changed:

```
$ go get -u github.com/go-bindata/go-bindata/...
$ make bindata
```